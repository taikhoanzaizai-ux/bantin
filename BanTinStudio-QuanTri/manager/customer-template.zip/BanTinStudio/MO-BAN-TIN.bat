@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
start "" "%~dp0Quân Bản Tin.exe"
